Product Name
---------------
Modern Admin - Clean Bootstrap 4 Dashboard HTML Template


Product Description
-------------------
Modern admin includes 7 pre-built templates with organized folder structure, clean & commented code,
1500+ pages, 500+ components, 100+ charts, 50+ advance cards (widgets), searchable navigation, RTL and incredible support.


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeForest. You can access documentation online as well.
Documentation URL: https://pixinvent.com/modern-admin-clean-bootstrap-4-dashboard-html-template/documentation

Change Log
----------
Read CHANGELOG.md file